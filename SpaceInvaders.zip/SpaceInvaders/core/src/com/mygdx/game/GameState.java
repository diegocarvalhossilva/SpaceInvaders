package com.mygdx.game;

public enum GameState {
	MENU, GAME, END;

}
